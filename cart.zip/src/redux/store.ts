import { configureStore } from "@reduxjs/toolkit";
import { cartApi } from "./cartApi";
import { publiceApi } from "./pubilicApi";

const reduxStore = configureStore({
    reducer: {
        [cartApi.reducerPath]: cartApi.reducer,
        [publiceApi.reducerPath]: publiceApi.reducer,


    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(cartApi.middleware, publiceApi.middleware),
});

export type RootState = ReturnType<typeof reduxStore.getState>;
export type AppDispatch = typeof reduxStore.dispatch;

export default reduxStore;
