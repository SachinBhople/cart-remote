import React from 'react';
import { useGetAllproductQuery } from '../redux/pubilicApi';
import { Link } from 'react-router-dom';

const Product = () => {
    const { data } = useGetAllproductQuery();
    // let data = data.result
    return (
        <>
            {/* <h1>Product List</h1> */}
            <div className="row">
                {data && data.result.map((product: any) => (
                    <div key={product._id} className="col-md-4 mb-4">
                        <div className="card" style={{ width: '18rem' }}>

                            <img
                                src={product.images}
                                className="card-img-top"
                                alt={product.name}
                            />
                            <div className="card-body">
                                <h5 className="card-title">{product.name}</h5>
                                <p className="card-text">{product.desc}</p>
                                <p className="card-text">Price: ${product.price}</p>

                                <p className="card-text">MRP: ${product.mrp}</p>
                                <p className="card-text">Stock: {product.stock}</p>
                                <Link to={`/product/${product._id}`} className="btn btn-primary">View Product</Link>
                            </div>
                        </div >
                    </div >
                ))}
            </div >

        </>
    );
}

export default Product;
