import React from 'react'

const Succses = () => {
    return (
        <div>Succses</div>
    )
}

export default Succses