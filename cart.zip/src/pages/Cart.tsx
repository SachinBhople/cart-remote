import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useDeleteItemFromCartMutation, useEmptyCartMutation, useGetAllproductsQuery } from '../redux/cartApi'



const Cart = () => {
    const { data } = useGetAllproductsQuery("668402180dfdb6358e94dc5c")
    const [deleteproduct] = useDeleteItemFromCartMutation()
    const [emptycart] = useEmptyCartMutation()
    return <>
        <div className="container my-5">
            <div className="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2>Shopping Cart</h2>
                </div>
                <div>
                    <button onClick={() => emptycart("668402180dfdb6358e94dc5c")} className="btn btn-sm btn-danger">Empty Cart</button>
                </div>
            </div>
            <div className="row">
                <div className="col-md-8">
                    <div className="card mb-3">
                        {data && data.result.map(item => <div className="row g-0">
                            <div className="col-md-4">
                                <img height={100} src={item.productId.images} alt="Product" />
                            </div>
                            <div className="col-md-8">
                                <div className="card-body">
                                    <h5 className="card-title">Product Name: {item.productId.name}</h5>
                                    <p className="card-text"> Prdouct Price:{item.productId.price}</p>
                                    <div className="d-flex align-items-center">
                                        <label htmlFor="quantity" className="me-2">Qty:{item.quantity}</label>
                                        <input type="number" id="quantity" className="form-control w-25 me-3" value="1" min="1" />
                                        <button onClick={() => deleteproduct(item._id)} className="btn btn-danger btn-sm">Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div>)}
                        {/* <div className="row g-0">
                            <div className="col-md-4">
                                <img src="https://images.unsplash.com/photo-1731323036230-fb37b4d9ed71?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwzfHx8ZW58MHx8fHx8" className="img-fluid rounded-start" alt="Product" />
                            </div>
                            <div className="col-md-8">
                                <div className="card-body">
                                    <h5 className="card-title">Product Name</h5>
                                    <p className="card-text">$99.99</p>
                                    <div className="d-flex align-items-center">
                                        <label htmlFor="quantity" className="me-2">Qty:</label>
                                        <input type="number" id="quantity" className="form-control w-25 me-3" value="1" min="1" />
                                        <button className="btn btn-danger btn-sm">Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div> */}
                    </div>

                </div>
                <div className="col-md-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">Order Summary</h5>
                            <p className="card-text">Subtotal: $99.99</p>
                            <p className="card-text">Shipping: $5.00</p>
                            <p className="card-text"><strong>Total: $104.99</strong></p>
                            <Link to="/checkout" className="btn btn-primary w-100">Proceed to Checkout</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </>
}

export default Cart