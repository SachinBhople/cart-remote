import React from 'react'

const Test = () => {
    return <>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="id" />
            <label class="form-check-label" for="id">
                checkbox
            </label>
        </div>
    </>
}

export default Test